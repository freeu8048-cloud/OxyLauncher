package com.example.oxylauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    data class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private val apps = mutableListOf<AppItem>()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var gesture: GestureDetector
    private lateinit var root: FrameLayout
    private lateinit var homeView: LinearLayout
    private lateinit var drawer: GridView
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView

    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        loadApps()

        gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (drawer.visibility == View.GONE && vy < -800) showDrawer()
                else if (drawer.visibility == View.VISIBLE && vy > 800) hideDrawer()
                return true
            }
        })

        root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0E0E12"))
            fitsSystemWindows = true
            setOnTouchListener { _, ev -> gesture.onTouchEvent(ev); false }
        }

        homeView = buildHome()
        drawer = buildDrawer()

        root.addView(homeView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(drawer, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        drawer.visibility = View.GONE

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        updateClock()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawer.visibility == View.VISIBLE) hideDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) hideDrawer()
    }

    private fun showDrawer() {
        drawer.alpha = 0f
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).setDuration(200).start()
        homeView.animate().alpha(0f).setDuration(200).start()
    }

    private fun hideDrawer() {
        drawer.animate().alpha(0f).setDuration(200).withEndAction {
            drawer.visibility = View.GONE
        }.start()
        homeView.animate().alpha(1f).setDuration(200).start()
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
            .forEach { apps.add(it) }
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
        if (drawer.visibility == View.VISIBLE) hideDrawer()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundIcon(d: Drawable, sizeDp: Int): Drawable {
        val px = dp(sizeDp)
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val path = Path().apply {
            addRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()),
                px * 0.28f, px * 0.28f, Path.Direction.CW)
        }
        canvas.clipPath(path)
        d.setBounds(0, 0, px, px)
        d.draw(canvas)
        return BitmapDrawable(resources, bmp)
    }

    private fun iconView(item: AppItem, sizeDp: Int): ImageView =
        ImageView(this).apply { setImageDrawable(roundIcon(item.icon, sizeDp)) }

    private fun buildHome(): LinearLayout {
        dateText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#BBBBBB"))
        }
        clockText = TextView(this).apply {
            textSize = 72f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#33FFFFFF"))
            }
            // Dock mein pehle 4 apps. Chaho to yahan apne favourite package names rakh sakte ho.
            apps.take(4).forEach { item ->
                addView(iconView(item, 56).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)).apply {
                        setMargins(dp(6), 0, dp(6), 0)
                    }
                    setOnClickListener { launch(item.pkg) }
                })
            }
        }

        val hint = TextView(this).apply {
            text = "↑ Swipe up for apps"
            setTextColor(Color.parseColor("#77FFFFFF"))
            textSize = 12f
            gravity = Gravity.CENTER
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(56), dp(24), dp(24))
            addView(dateText)
            addView(clockText)
            addView(View(this@MainActivity), LinearLayout.LayoutParams(0, 0, 1f))
            addView(dock, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(12)
            })
            addView(hint)
        }
    }

    private fun buildDrawer(): GridView {
        return GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(12)
            horizontalSpacing = dp(4)
            setBackgroundColor(Color.parseColor("#F0000000"))
            setPadding(dp(12), dp(64), dp(12), dp(24))
            clipToPadding = false
            adapter = AppAdapter()
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos].pkg) }
            setOnTouchListener { _, ev -> gesture.onTouchEvent(ev); false }
        }
    }

    private fun updateClock() {
        val now = Date()
        clockText.text = SimpleDateFormat("hh:mm", Locale.getDefault()).format(now)
        dateText.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = apps.size
        override fun getItem(position: Int): Any = apps[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = apps[position]
            return LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(8), 0, dp(8))
                addView(iconView(item, 52))
                addView(TextView(this@MainActivity).apply {
                    text = item.label
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                })
            }
        }
    }
}
